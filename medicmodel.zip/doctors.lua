layer_manager.AddValidModel( "Medic_1", "models/player/portal/Male_02_Medic.mdl" )
list.Set( "PlayerOptionsModel", "Medic_1", "models/player/portal/Male_02_Medic.mdl" )

player_manager.AddValidModel( "Medic_2", "models/player/portal/Male_04_Medic.mdl" )
list.Set( "PlayerOptionsModel", "Medic_2", "models/player/portal/Male_04_Medic.mdl" )

player_manager.AddValidModel( "Medic_3", "models/player/portal/Male_05_Medic.mdl" )
list.Set( "PlayerOptionsModel", "Medic_3", "models/player/portal/Male_05_Medic.mdl" )

player_manager.AddValidModel( "Medic_4", "models/player/portal/Male_06_Medic.mdl" )
list.Set( "PlayerOptionsModel", "Medic_4", "models/player/portal/Male_06_Medic.mdl" )

player_manager.AddValidModel( "Medic_5", "models/player/portal/Male_07_Medic.mdl" )
list.Set( "PlayerOptionsModel", "Medic_5", "models/player/portal/Male_07_Medic.mdl" )

player_manager.AddValidModel( "Medic_6", "models/player/portal/Male_08_Medic.mdl" )
list.Set( "PlayerOptionsModel", "Medic_6", "models/player/portal/Male_08_Medic.mdl" )

player_manager.AddValidModel( "Medic_7", "models/player/portal/Male_09_Medic.mdl" )
list.Set( "PlayerOptionsModel", "Medic_7", "models/player/portal/Male_09_Medic.mdl" )
"